using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManagement : MonoBehaviour
{
    public GameObject gameOverUI;
    public GameObject pauseMenuUI;

    public void gameOver()
    {
        gameOverUI.SetActive(true);
    }

    public void gamePause()
    {
        Time.timeScale = 0;
        pauseMenuUI.SetActive(true);
    }

    public void restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void quit()
    {
       Application.Quit();
    }

    public void resume()
    {
        Time.timeScale = 1;
        pauseMenuUI.SetActive(false);
    }
}
