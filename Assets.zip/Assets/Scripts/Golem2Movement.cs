using UnityEngine;

public class Golem2Movement : MonoBehaviour
{
    public float speed;
    private bool shouldFlip = true;

    void FixedUpdate()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime);
            if(shouldFlip == true)
            {
                transform.eulerAngles = new Vector3(0, -180, 0);
            }
            else
            {
                transform.eulerAngles = new Vector3(0, 0, 0);
            }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            var healthObj = collision.gameObject.GetComponent<PlayerHealth>();
            if(healthObj != null)
            {
                healthObj.takeDamage(1);
            }
            /*if(healthObj.health < 0 && !dead)
            {
                dead = true;
                Destroy(collision.gameObject);
            }*/
        }
    }
}
