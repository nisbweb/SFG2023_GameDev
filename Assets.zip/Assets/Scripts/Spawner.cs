using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject golem;
    public float interval = 300;
    private float timeGap = 0;
    
    void FixedUpdate()
    {
        timeGap += 1;

        if(timeGap >= interval){
            timeGap = 0;
            Instantiate(golem, transform.position,transform.rotation);

        }
    }
}
