using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public float speed;
    private bool shouldFlip = true;
    public Transform triggerCheck;
    //private bool dead ;

    void FixedUpdate()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime); 
        RaycastHit2D triggerInfo = Physics2D.Raycast(triggerCheck.position, Vector2.up, 50f);
        if(triggerInfo.collider == false)
        {
            if(shouldFlip == true)
            {
                transform.eulerAngles = new Vector3(0, -180, 0);
                shouldFlip = false;
            }
            else
            {
                transform.eulerAngles = new Vector3(0, 0, 0);
                shouldFlip = true;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            var healthObj = collision.gameObject.GetComponent<PlayerHealth>();
            if(healthObj != null)
            {
                healthObj.takeDamage(1);
            }
            /*if(healthObj.health < 0 && !dead)
            {
                dead = true;
                Destroy(collision.gameObject);
            }*/
        }
    }
}
