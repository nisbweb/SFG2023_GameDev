using UnityEngine;

public class EnemyKill : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D stomp)
    {
        var healthObj = transform.parent.gameObject.GetComponent<PlayerHealth>();
        if(stomp.gameObject.tag == "weakPoint")
        {
            healthObj.negateDamage(1);
            Destroy(stomp.gameObject);
        }
    }
}
