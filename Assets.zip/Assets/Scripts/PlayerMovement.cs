using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed;                 // speed
    public float jumpForce;             // jump force
    Vector2 move;                       // horizontal and vertical axis values
    Rigidbody2D rb;                     // gameObject rigid body reference variable
    Animator anim;                      // gameObject animator reference variable
    bool flippedBack;                   // flip checker
    bool onGround;                      // on ground checker
    public Transform feet;              // feet on ground?
    public float checkRadius;           // radius of circle
    public LayerMask groundObj;         // ground layer selector

    void Start()
    {
        // get reference to components
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();

        // others initializations
        flippedBack = false;
        onGround = true;
    }

    void FixedUpdate()
    {
        // run action
        rb.velocity = new Vector2(move.x * speed * Time.deltaTime, rb.velocity.y);
        
    }

    void Update()
    {
        // fetching values along horizaontal and vertical axis
        move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

        // running animation
        if(move.x == 0)
        {
            anim.SetBool("isRunning", false);
        }
        else 
        {
            anim.SetBool("isRunning", true);
        }

        // flipping checks
        if(move.x < 0 && !flippedBack)
        {
            Flip();
        }
        else if(move.x > 0 && flippedBack)
        {
            Flip();
        }

        // check if on ground
        onGround = Physics2D.OverlapCircle(feet.position, checkRadius, groundObj);

        // ground animation
        if(onGround)
        {
            anim.SetBool("onGround", true);
        }
        else
        {
            anim.SetBool("onGround", false);
        }

        // jump action
         if(Input.GetKeyDown(KeyCode.UpArrow) && onGround)
        {
            rb.velocity = new Vector2(rb.velocity.x, move.y * jumpForce);
        }
    }
    
    // flipping left and right
    void Flip()
    {
        Vector2 currentScale = transform.localScale;
        currentScale.x *= -1;
        transform.localScale = currentScale;

        flippedBack = !flippedBack;
    }
}
